<?php
function precompile() {
	
	
	return 0;
}

precompile();